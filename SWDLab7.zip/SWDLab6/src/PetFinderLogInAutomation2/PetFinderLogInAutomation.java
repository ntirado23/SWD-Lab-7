import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class PetFinderLoginAutomation {

    public static void main(String[] args) throws InterruptedException {
    
        System.setProperty("webdriver.chrome.driver", "path_to_chromedriver.exe");

      
        WebDriver driver = new ChromeDriver();

        // Open PetFinder login page
        driver.get("http://petfinder.com/user/login");

        // Maximize the browser window
        driver.manage().window().maximize();

        // Enter username
        WebElement usernameField = driver.findElement(By.id("username"));
        usernameField.sendKeys("mytestqa2023@gmail.com");

        // Enter password
        WebElement passwordField = driver.findElement(By.id("password"));
        passwordField.sendKeys("Student#123");

        // Click "Done" button
        WebElement doneButton = driver.findElement(By.id("login_btn"));
        doneButton.click();

        // Sleep for a short while 
        Thread.sleep(3000);

        // Get the profile name
        WebElement profileNameElement = driver.findElement(By.className("username"));
        String profileName = profileNameElement.getText().trim();

        String expectedProfileName = "TriCeratops Horridus";
        if (profileName.equals(expectedProfileName)) {
            System.out.println("Login successful. Profile name matches.");
        } else {
            System.out.println("Login successful, but profile name does not match expected.");
        }

        
        driver.quit();
    }
}
